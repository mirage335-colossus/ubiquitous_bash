#!/usr/bin/env bash

#Green. Working as expected.
_messagePlain_good() {
	echo -e -n '\E[0;32m '
	echo -n "$@"
	echo -e -n ' \E[0m'
	echo
	return 0
}

#Yellow. May or may not be a problem.
_messagePlain_warn() {
	echo -e -n '\E[1;33m '
	echo -n "$@"
	echo -e -n ' \E[0m'
	echo
	return 0
}

#Red. Will result in missing functionality, reduced performance, etc, but not necessarily program failure overall.
_messagePlain_bad() {
	echo -e -n '\E[0;31m '
	echo -n "$@"
	echo -e -n ' \E[0m'
	echo
	return 0
}

	
export scriptAbsoluteLocation="/home/commonadmin/core/infrastructure/ubiquitous_bash/ubiquitous_bash.sh"
export scriptAbsoluteFolder="/home/commonadmin/core/infrastructure/ubiquitous_bash"
export sessionid="dxdYxygxYo3zzkU8kc"


#Special. Signals do NOT reset metaID .
export metaEmbed="true"

#near equivalent: _set_me_host
	export metaBase="/home/commonadmin/project/_playground/mebase"
	export metaObjName="_example_processor_name"
	export metaTmp="/home/commonadmin/core/infrastructure/ubiquitous_bash"""/.m_"dxdYxygxYo3zzkU8kc"
	export metaProc="/home/commonadmin/project/_playground/mebase/.m_dxdYxygxYo3zzkU8kc"
	# WARNING: Setting metaProc to a value not including sessionid disables automatic removal by default!
	#export metaProc="/home/commonadmin/project/_playground/mebase"""/.m_"dxdYxygxYo3zzkU8kc"

export metaType="base"

export metaID="KnEKoweJrSw5ufn4pJ"

export metaPath="KnEKoweJrSw5ufn4pJ"

#export metaDir_tmp="/home/commonadmin/core/infrastructure/ubiquitous_bash/.m_dxdYxygxYo3zzkU8kc"/"KnEKoweJrSw5ufn4pJ"
#export metaDir_base="/home/commonadmin/project/_playground/mebase/.m_dxdYxygxYo3zzkU8kc"/"KnEKoweJrSw5ufn4pJ"

#near equivalent _set_me_dir
	#export metaDir_tmp="/home/commonadmin/core/infrastructure/ubiquitous_bash/.m_dxdYxygxYo3zzkU8kc"/"KnEKoweJrSw5ufn4pJ"
	#export metaDir_base="/home/commonadmin/project/_playground/mebase/.m_dxdYxygxYo3zzkU8kc"/"KnEKoweJrSw5ufn4pJ"
	#export metaDir="/home/commonadmin/core/infrastructure/ubiquitous_bash/.m_dxdYxygxYo3zzkU8kc/KnEKoweJrSw5ufn4pJ"
	export metaDir_tmp="/home/commonadmin/core/infrastructure/ubiquitous_bash/.m_dxdYxygxYo3zzkU8kc/KnEKoweJrSw5ufn4pJ"
	export metaDir_base="/home/commonadmin/project/_playground/mebase/.m_dxdYxygxYo3zzkU8kc/KnEKoweJrSw5ufn4pJ"
	export metaDir="/home/commonadmin/project/_playground/mebase/.m_dxdYxygxYo3zzkU8kc/KnEKoweJrSw5ufn4pJ"
	#[[ "base" == "base" ]] && export metaDir="/home/commonadmin/project/_playground/mebase/.m_dxdYxygxYo3zzkU8kc/KnEKoweJrSw5ufn4pJ" && _messagePlain_warn 'metaType= base'
	#[[ "base" == "" ]] && _messagePlain_good 'metaType= '
	[[ "base" == "base" ]] && _messagePlain_warn 'metaType= base'
	[[ "base" == "" ]] && _messagePlain_good 'metaType= '

export metaReg="/home/commonadmin/project/_playground/mebase/_reg"

export in_me_a_path="/home/commonadmin/project/_playground/mebase/_reg/grid/0/0/3"
export in_me_b_path="/home/commonadmin/project/_playground/mebase/_reg/grid/0/1/3"
export out_me_a_path="/home/commonadmin/project/_playground/mebase/_reg/grid/0/0/4"
export out_me_b_path="/home/commonadmin/project/_playground/mebase/_reg/grid/0/1/4"





. "/home/commonadmin/core/infrastructure/ubiquitous_bash/ubiquitous_bash.sh" --embed "$@"
