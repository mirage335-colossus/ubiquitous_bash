#!/usr/bin/env bash

export scriptAbsoluteLocation="/home/commonadmin/core/infrastructure/ubiquitous_bash/ubiquitous_bash.sh"
export scriptAbsoluteFolder="/home/commonadmin/core/infrastructure/ubiquitous_bash"
export sessionid="dxdYxygxYo3zzkU8kc"
. "/home/commonadmin/core/infrastructure/ubiquitous_bash/ubiquitous_bash.sh" --embed "$@"
